package com.cricket.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cricket.entity.Players;

public interface PlayersRepository extends JpaRepository<Players, Integer> {

	@Query(value="select * from players where r1>? and r2<?")
	List<Players> getByRunsRange(int r1, int r2);

}
