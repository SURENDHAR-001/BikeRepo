package com.std_result.entity;

public class Result {
	
	private int id;
	private String name;
	private int rollNo;
	private int total;
	private float percentage;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	
	public Result(int id, String name, int rollNo, int total, float percentage) {
		super();
		this.id = id;
		this.name = name;
		this.rollNo = rollNo;
		this.total = total;
		this.percentage = percentage;
	}
	
	
	@Override
	public String toString() {
		return "Result [id=" + id + ", name=" + name + ", rollNo=" + rollNo + ", total=" + total + ", percentage="
				+ percentage + "]";
	}
	
	
	
	
	
}
