package com.std_result.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.std_result.entity.Result;
import com.std_result.entity.SemOne;
import com.std_result.entity.SemTwo;
import com.std_result.entity.Student;

@RestController
@RequestMapping(value="/result")
public class ResultController {
	
	RestTemplate rt;
	
//	List<Result> x;
//	public  void setResult(List<Result> r) {
//		x = r;
//	}
	
	
	public List<Result> getResult() {
		
		String url1 = "http://localhost:8080/std/getAll";
		String url2 = "http://localhost:8081/semOne/getAll";
		String url3 = "http://localhost:8081/semTwo/getAll";
		
		ResponseEntity<List<Student>> r1 = rt.exchange(url1, HttpMethod.GET, null, new ParameterizedTypeReference <List<Student>>() {});
		List<Student> std =r1.getBody();
		
		ResponseEntity<List<SemOne>> r2 = rt.exchange(url2, HttpMethod.GET, null, new ParameterizedTypeReference <List<SemOne>>() {});
		List<SemOne> semOne =r2.getBody();
		
		ResponseEntity<List<SemTwo>> r3 = rt.exchange(url3, HttpMethod.GET, null, new ParameterizedTypeReference <List<SemTwo>>() {});
		List<SemTwo> semTwo =r3.getBody();
		
		List<Result> x= new ArrayList<>();
		
//		for(int i = 0 ; i<semOne.size(); i++) {
//			for(int j=0; j<=i; j++) {
//				x.get(i).setId(std.get(i).getId());
//				x.get(i).setName(std.get(i).getName());
//				x.get(i).setRollNo(std.get(i).getRollNo());
//				x.get(i).setTotal(semOne.get(i).getTotal()+semTwo.get(i).getTotal());
//				x.get(i).setPercentage((x.get(i).getTotal()*100)/200);
//			}
//		}
		
		for(int i=0; i<std.size(); i++) {
			int total = semOne.get(i).getTotal()+semTwo.get(i).getTotal();
			x.add(new Result(std.get(i).getId(), std.get(i).getName(), std.get(i).getRollNo(),total, (total*100/200)));
		}
		
//		for(Result r : x) {
//			std.forEach(z->{
//				r.setId(z.getId());
//				r.setRollNo(z.getRollNo());
//				r.setName(z.getName());
//			});
//		}
		
		x.forEach(t-> {
			System.out.println(t);
		});
		
		return x;
		
	}
	
}
