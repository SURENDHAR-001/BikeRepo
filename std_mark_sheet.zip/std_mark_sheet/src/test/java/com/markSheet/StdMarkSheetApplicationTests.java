package com.markSheet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StdMarkSheetApplicationTests {

	@Test
	void contextLoads() {
	}

}
