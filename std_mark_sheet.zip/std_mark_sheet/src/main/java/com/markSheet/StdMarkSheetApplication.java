package com.markSheet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StdMarkSheetApplication {

	public static void main(String[] args) {
		SpringApplication.run(StdMarkSheetApplication.class, args);
	}

}
