package com.ExceptionPractice.CustomException;

public class YearException extends Exception {
	public YearException(String a) {
		super(a);
	}
}

