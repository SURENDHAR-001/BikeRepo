package com.ExceptionPractice.CustomException;

public class ObjectNotFoundException extends Exception{
	
	public ObjectNotFoundException() {
		super();
	}
}
