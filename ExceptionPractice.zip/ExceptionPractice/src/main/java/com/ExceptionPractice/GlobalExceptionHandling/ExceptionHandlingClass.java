package com.ExceptionPractice.GlobalExceptionHandling;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ExceptionPractice.CustomException.ObjectNotFoundException;

@RestControllerAdvice
public class ExceptionHandlingClass {
	
	
	
	
	@ExceptionHandler(NullPointerException.class)
	public String nullObj(NullPointerException npe) {
		return "adf ";
	}
	
}
